import React from "react";

function ContentWrite() {
    return (
        <div>
            ContentWrite!
        </div>
    )
}

export default ContentWrite;