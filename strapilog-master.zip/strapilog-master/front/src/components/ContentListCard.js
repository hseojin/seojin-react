import React from 'react';
import { Alert, Card, List } from 'antd';
import useSWR from 'swr';
import axios from 'axios';
import dayjs from 'dayjs';

function ContentListCard() {
    const fetcher = url => axios.get(url).then(res => res.data);
    const { data, error } = useSWR('http://localhost:1337/blogs', fetcher);
    
    return (
        <>
            {
                error ? (
                    <Alert 
                        message='문제가 발생했습니다!'
                        type='error'
                        closable
                    />
                ) : (
                    <List 
                        dataSource={data}
                        loading={!data}
                        renderItem={item => (
                            <List.Item>
                                <Card title={item.title}>
                                    최종 수업일: {dayjs(item.updated_at).format('YYYY-MM-DD')}
                                </Card>
                            </List.Item>
                        )}
                    />
                )
            }
        </>
    )
}

export default ContentListCard;
