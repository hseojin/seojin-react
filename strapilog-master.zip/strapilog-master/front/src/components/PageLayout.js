import { Button, PageHeader, Space } from 'antd';
import { Link } from "react-router-dom";

const pageLayoutWrapperStyles = {
    width: '100vw',
}

const pageLayoutStyles = {
    width: '80%',
    margin: '0 auto'
}

function PageLayout({ children, hasExtra=false }) {
    return (
        <Space direction='vertical' style={pageLayoutWrapperStyles}>
            <PageHeader
                title='수정고 블로그'
                subTitle='수정고 특강'
                extra= {
                    hasExtra && (
                        <Space>
                            <Link to='/write'>
                                <Button>기록하러 가기</Button>
                            </Link>
                        </Space>
                    )
                }
            />
            <div style={pageLayoutStyles}>
                {children}
            </div>
        </Space>
    )
}

export default PageLayout;