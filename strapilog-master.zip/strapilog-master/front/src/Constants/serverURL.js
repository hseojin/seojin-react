const SERVER_URL = 'http://localhost:1337';

export {
    SERVER_URL
}