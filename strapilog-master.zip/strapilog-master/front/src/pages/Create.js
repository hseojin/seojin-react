import { message } from "antd";
import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router";
import { mutate } from "swr";
import ContentWrite from "../components/ContentWrite";
import PageLayout from "../components/PageLayout";
import { SERVER_URL } from "../Constants/serverURL";

function Create() {
    const[loading, setLoading] = useState(false)
    const navigation = useNavigate();
    const handleSubmit = async (values) => {
        setLoading(true);
        try {
            await axios.post(`${SERVER_URL}/blogs/`, {
                title: values.title,
                content: values.content,
            });
            mutate(`${SERVER_URL}/blogs/`);
        } catch (error) {
            console.error(error);
        }
        setLoading(false);
        message.success('등록이 완료 되었습니다!');
        navigation('/');
    }
    return (
        <PageLayout>
            <ContentWrite onSubmit={handleSubmit} loading={loading} />
        </PageLayout>
    )
}

export default Create;