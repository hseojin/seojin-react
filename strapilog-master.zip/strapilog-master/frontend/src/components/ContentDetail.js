import React from 'react'

function ContentDetail() {
  return (
    <div>
      
    </div>
  )
}

export default ContentDetail
