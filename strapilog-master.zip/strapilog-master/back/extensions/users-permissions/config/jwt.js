module.exports = {
  jwtSecret: process.env.JWT_SECRET || '150aa4e7-f109-49d2-be91-ed79e870154b'
};