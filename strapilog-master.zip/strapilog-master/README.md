# strapilog

| Strapi는 REST API를 쉽게 만들 수 있게 도와주는 Open source Node.js Headless CMS 툴입니다.

